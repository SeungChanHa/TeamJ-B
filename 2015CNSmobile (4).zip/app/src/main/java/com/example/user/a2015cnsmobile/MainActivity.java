package com.example.user.a2015cnsmobile;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        Intent intent1 = null;
        switch (v.getId()) {
            case R.id.button1:
                intent1 = new Intent(this, Menu01.class);
                break;
            case R.id.button2:
                intent1 = new Intent(this, cnsnews.class);
                break;
            case R.id.button4:
                intent1 = new Intent(this, Menu04.class);
                break;
            case R.id.button5:
                intent1 = new Intent(this, Menu05.class);
                break;
            case R.id.button6:
                intent1 = new Intent(this, MapsActivity2.class);
                break;
            case R.id.button10:
                intent1 = new Intent(this, Menu08.class);
                break;
            case R.id.gnubt:
                intent1 = new Intent(this, gnu.class);
                break;

        }
        startActivity(intent1);
}
}
