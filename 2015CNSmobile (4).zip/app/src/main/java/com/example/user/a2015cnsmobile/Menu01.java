package com.example.user.a2015cnsmobile;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.TabHost;


@SuppressWarnings("deprecation")
public class Menu01 extends TabActivity {

    TabHost mTab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TabHost mTab = getTabHost();
        TabHost.TabSpec spec;

        LayoutInflater.from(this).inflate(R.layout.activity_menu01, mTab.getTabContentView(), true);

        spec = mTab.newTabSpec("tab1").setIndicator("학장님소개")
                .setContent(R.id.tv1);
        mTab.addTab(spec);
        spec = mTab.newTabSpec("tab2").setIndicator("학생회소개")
                .setContent(R.id.tv2);
        mTab.addTab(spec);
        spec = mTab.newTabSpec("tab3").setIndicator("학과소개")
                .setContent(R.id.tv3);
        mTab.addTab(spec);
    }

    @Override
public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.activity_menu01, menu);
    return true;
    }

    public void onClick(View v) {
        Intent intent1 = null;
        switch (v.getId()) {
            case R.id.major1:
                intent1 = new Intent(this, Major1.class);
                break;
            case R.id.major2:
                intent1 = new Intent(this, Major2.class);
                break;
            case R.id.major3:
                intent1 = new Intent(this, Major3.class);
                break;
            case R.id.major4:
                intent1 = new Intent(this, Major4.class);
                break;
            case R.id.major5:
                intent1 = new Intent(this, Major5.class);
                break;
            case R.id.major6:
                intent1 = new Intent(this, Major6.class);
                break;
            case R.id.major7:
                intent1 = new Intent(this, Major7.class);
                break;
            case R.id.major8:
                intent1 = new Intent(this, Major8.class);
                break;
            case R.id.major9:
                intent1 = new Intent(this, Major9.class);
                break;
        }
        startActivity(intent1);
    }
}





