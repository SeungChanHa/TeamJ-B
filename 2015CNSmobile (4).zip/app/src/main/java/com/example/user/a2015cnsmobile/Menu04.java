package com.example.user.a2015cnsmobile;

import android.app.TabActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TabHost;

@SuppressWarnings("deprecation")
public class Menu04 extends TabActivity {

    TabHost mTab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TabHost mTab = getTabHost();
        TabHost.TabSpec spec;

        LayoutInflater.from(this).inflate(R.layout.activity_menu04, mTab.getTabContentView(), true);

        spec = mTab.newTabSpec("tab1").setIndicator("앨리토익")
                .setContent(R.id.tv1);
        mTab.addTab(spec);
        spec = mTab.newTabSpec("tab2").setIndicator("카페예누")
                .setContent(R.id.tv2);
        mTab.addTab(spec);
        spec = mTab.newTabSpec("tab3").setIndicator("플랜비")
                .setContent(R.id.tv3);
        mTab.addTab(spec);
        spec = mTab.newTabSpec("tab4").setIndicator("신전떡볶이")
                .setContent(R.id.tv4);
        mTab.addTab(spec);
        spec = mTab.newTabSpec("tab5").setIndicator("유니쿰")
                .setContent(R.id.tv5);
        mTab.addTab(spec);
        spec = mTab.newTabSpec("tab6").setIndicator("모모스테이크")
                .setContent(R.id.tv6);
        mTab.addTab(spec);

        Button btn1 = (Button) findViewById(R.id.calling1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-2087-3816"));
                startActivity(intent);
            }
        });

        Button btn2 = (Button) findViewById(R.id.calling2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-2087-3816"));
                startActivity(intent);
            }
        });

        Button btn3 = (Button) findViewById(R.id.calling3);

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-2087-3816"));
                startActivity(intent);
            }
        });

        Button btn4 = (Button) findViewById(R.id.calling4);

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-2087-3816"));
                startActivity(intent);
            }
        });

        Button btn5 = (Button) findViewById(R.id.calling5);

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-2087-3816"));
                startActivity(intent);
            }
        });

        Button btn6 = (Button) findViewById(R.id.calling6);

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-2087-3816"));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_menu04, menu);
        return true;
    }


}


