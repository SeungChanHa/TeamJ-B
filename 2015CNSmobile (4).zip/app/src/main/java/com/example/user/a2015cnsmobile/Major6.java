package com.example.user.a2015cnsmobile;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Major6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_major6);
    }
}
