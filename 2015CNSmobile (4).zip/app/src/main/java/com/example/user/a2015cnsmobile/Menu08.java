package com.example.user.a2015cnsmobile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;


import static com.example.user.a2015cnsmobile.R.id.webView02;

public class Menu08 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manu08);

        WebView WebView02 = (WebView) findViewById(webView02);
        WebView02.setWebChromeClient(new WebChromeClient());

        WebSettings webSettings = WebView02.getSettings();
        webSettings.setJavaScriptEnabled(true);

        WebView02.loadUrl("https://www.facebook.com/parade2017/");

    }
}
