package com.example.user.a2015cnsmobile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import static com.example.user.a2015cnsmobile.R.id.webView03;

public class gnu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gnu);
        WebView WebView03 = (WebView) findViewById(webView03);
        WebView03.setWebChromeClient(new WebChromeClient());

        WebSettings webSettings = WebView03.getSettings();
        webSettings.setJavaScriptEnabled(true);

        WebView03.loadUrl("http://gnu.ac.kr/");


    }
}