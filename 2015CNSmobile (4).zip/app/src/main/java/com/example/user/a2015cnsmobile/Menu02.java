package com.example.user.a2015cnsmobile;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.Date;
import java.util.Vector;

public class Menu02 extends AppCompatActivity {

    Vector vec;
    int firstDay;

    int totDays;
    int iYear;
    int iMonth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu02);

        Date today = new Date();
                iYear = today.getYear();
                iMonth = today.getMonth();

        vec = new Vector();
        TableLayout table = (TableLayout)findViewById( R.id.table );
        for( int i = 0 ; i < 6 ; i++ ){
            TableRow tr = new TableRow( this );
            for( int j = 0 ; j < 7 ; j++ ){
                TextView tv = new TextView( this );

                if( j == 0 )
                    tv.setTextColor( Color.RED );
                else if( j == 6 )
                    tv.setTextColor( Color.BLUE );

                else
                tv.setTextColor( Color.BLACK );

                tv.setGravity( Gravity.CENTER_HORIZONTAL );

                tr.addView( tv );
                vec.add( tv );
            }
            table.addView( tr );
        }

        table.setStretchAllColumns( true );

        table = (TableLayout)findViewById( R.id.week );
        table.setStretchAllColumns( true );

        setCalendar( iYear, iMonth );

        Button btn = (Button)findViewById( R.id.pre );
        btn.setOnClickListener( new Button.OnClickListener(){

            public void onClick(View v) {

                iMonth--;
                setCalendar( iYear, iMonth );

            }
        });

        btn = (Button)findViewById( R.id.next );
        btn.setOnClickListener( new Button.OnClickListener(){

            public void onClick(View v) {

                iMonth++;
                setCalendar( iYear, iMonth );

            }
        });
    }

    private void setCalendar( int year, int month ){


        Date date = new Date();
        date.setYear( year );
        date.setMonth( month );
        date.setDate( 1 );
        firstDay = date.getDay();

        totDays = 31;
        for( int i = 29 ; i <= 32 ; i++ ){
            date.setDate( i );
            if( date.getDate() == 1 ){
                totDays = i - 1;
                break;
            }
        }

        Log.i("mylog", firstDay + " " + totDays );
        date = new Date();
        date.setYear( year );
        date.setMonth( month );

        iYear = date.getYear();
        iMonth = date.getMonth();

        TextView tvToday = (TextView)findViewById( R.id.today );
        tvToday.setText( (iYear + 1900) + "년" + (iMonth + 1) + "월");



        for( int i = 0 ; i < vec.size() ; i++ ){
            ((TextView)vec.get( i )).setText("");
        }

        int iDate = 1;
        for( int i = firstDay ; i < firstDay + totDays; i++ ){

            ((TextView)vec.get( i )).setText( String.valueOf( iDate++ ) );
        }

    }
}




