package com.example.user.a2015cnsmobile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import static com.example.user.a2015cnsmobile.R.id.webView01;


public class Menu05 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu05);
        WebView WebView01 = (WebView) findViewById(webView01);
        WebView01.setWebChromeClient(new WebChromeClient());

        WebSettings webSettings = WebView01.getSettings();
        webSettings.setJavaScriptEnabled(true);

        WebView01.loadUrl("https://jobs.gnu.ac.kr/jobMain.do");





    }
}