package com.example.skill.googlemap3;
import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity3 extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps3);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    public void buttonClicked(View v) {
        switch (v.getId()) {

            case R.id.gps:
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                mMap.setMyLocationEnabled(true);

        }
    }



    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


       // LatLng gnu = new LatLng(35.155168, 128.096965);
        //mMap.addMarker(new MarkerOptions().position(gnu).title("Marker in GNU"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(gnu));
        LatLng COLLEGE = new LatLng(35.155168, 128.096965);
        LatLng curPoint= new LatLng(35.155168, 128.096965);
        Marker college = mMap.addMarker(new MarkerOptions().position(COLLEGE));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(COLLEGE));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(curPoint, 17));



    }
}



